import { useState } from 'react';

function EmployeeForm() {
  const [formData, setFormData] = useState({
    name: '',
    designation: '',
    location: '',
    salary: ''
  });

  const [errors, setErrors] = useState({});

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.designation.trim()) newErrors.designation = 'Designation is required';
    if (!formData.location.trim()) newErrors.location = 'Location is required';
    if (!formData.salary.trim()) newErrors.salary = 'Salary is required';
    else if (isNaN(formData.salary)) newErrors.salary = 'Salary must be a number';
    return newErrors;
  };

  const handleSubmit = e => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
    } else {
      console.log('Form Data:', formData);
      alert('Form submitted successfully!');
      setFormData({ name: '', designation: '', location: '', salary: '' });
      setErrors({});
    }
  };

  return (
    <div className="container mt-4">
      <h2>Employee Form</h2>
      <form onSubmit={handleSubmit} className="mt-3">
        {['name', 'designation', 'location', 'salary'].map(field => (
          <div className="mb-3" key={field}>
            <label className="form-label text-capitalize">{field}</label>
            <input
              name={field}
              value={formData[field]}
              onChange={handleChange}
              className={`form-control ${errors[field] ? 'is-invalid' : ''}`}
            />
            {errors[field] && <div className="invalid-feedback">{errors[field]}</div>}
          </div>
        ))}
        <button className="btn btn-primary">Submit</button>
      </form>
    </div>
  );
}

export default EmployeeForm;