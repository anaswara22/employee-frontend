import { useEffect, useState } from 'react';

function Dashboard() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(res => res.json())
      .then(data => setUsers(data));
  }, []);

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Employee Dashboard</h2>
      <div className="row">
        {users.map(user => (
          <div className="col-md-4 mb-4" key={user.id}>
            <div className="card shadow-sm h-100">
              <div className="card-body">
                <h5 className="card-title">{user.name}</h5>
                <p className="card-text">
                  <strong>ID:</strong> {user.id}<br />
                  <strong>Email:</strong> {user.email}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Dashboard;